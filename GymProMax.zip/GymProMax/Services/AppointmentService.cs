﻿using GymProMax.Data;
using GymProMax.Models;
using System;
using System.Linq;

namespace GymProMax.Services
{
    public class AppointmentService : IAppointmentService
    {
        private readonly ApplicationDbContext _context;

        public AppointmentService(ApplicationDbContext context) => _context = context;

        public bool IsSlotAvailable(int trainerId, DateTime date)
        {
            // Seçilen saatte başka randevu var mı kontrol ediyoruz
            return !_context.Appointments.Any(a => a.TrainerId == trainerId && a.AppointmentDate == date);
        }

        public void ConfirmAppointment(int appointmentId)
        {
            var app = _context.Appointments.Find(appointmentId);
            if (app != null)
            {
                // DÜZELTME BURADA:
                // Eski: app.IsConfirmed = true;
                // Yeni: app.Status = "Onaylandı";
                app.Status = "Onaylandı";

                _context.SaveChanges();
            }
        }
    }
}