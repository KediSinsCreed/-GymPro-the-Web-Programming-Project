﻿using GymProMax.Models;

namespace GymProMax.Services
{
    public interface IAppointmentService
    {
        bool IsSlotAvailable(int trainerId, DateTime date);

        void ConfirmAppointment(int appointmentId);
    }
}