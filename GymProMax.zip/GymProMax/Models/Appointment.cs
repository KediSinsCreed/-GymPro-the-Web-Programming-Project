﻿using System.ComponentModel.DataAnnotations;

namespace GymProMax.Models
{
    public class Appointment
    {
        public int Id { get; set; }

        public string MemberId { get; set; } // Hata veren kısım
        public string MemberName { get; set; }

        public int ServiceId { get; set; } // SQL hatasının ana sebebi
        public string ServiceName { get; set; }

        public int TrainerId { get; set; }
        public virtual Trainer Trainer { get; set; }

        public DateTime AppointmentDate { get; set; }

        // Varsayılan değer atıyoruz ki boş kalmasın
        public string Status { get; set; } = "Bekliyor";
    }
}