﻿using System.ComponentModel.DataAnnotations;

namespace GymProMax.Models
{
    public class Trainer
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Ad Soyad zorunludur.")]
        [Display(Name = "Ad Soyad")]
        public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Uzmanlık alanı zorunludur.")]
        [Display(Name = "Uzmanlık Alanı")]
        public string Specialization { get; set; } = string.Empty;

        [Display(Name = "Fotoğraf Yolu")]
        public string? ImageUrl { get; set; }

        [Required(ErrorMessage = "Biyografi zorunludur.")]
        [Display(Name = "Biyografi")]
        public string Biography { get; set; } = string.Empty;

        // KRİTİK DÜZELTME: Bu listeyi 'new List' ile başlatıyoruz ki 'Boş' hatası vermesin.
        public ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
    }
}