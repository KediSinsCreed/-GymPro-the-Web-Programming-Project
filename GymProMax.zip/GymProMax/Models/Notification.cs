﻿using System;

namespace GymProMax.Models
{
    public class Notification
    {
        public int Id { get; set; }

        // Bildirim kime gidecek? (Üye ID)
        public string UserId { get; set; } = string.Empty;

        // Mesaj ne? (Örn: "Pilates randevunuz onaylandı.")
        public string Message { get; set; } = string.Empty;

        // Okundu mu? (Kırmızı baloncuk için)
        public bool IsRead { get; set; } = false;

        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}