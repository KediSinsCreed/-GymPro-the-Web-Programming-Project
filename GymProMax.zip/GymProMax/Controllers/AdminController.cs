﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GymProMax.Data;
using GymProMax.Models;
using Microsoft.AspNetCore.Authorization;

namespace GymProMax.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Randevu listesini eğitmen ve hizmet bilgilerini dahil ederek getirir
        public async Task<IActionResult> Index()
        {
            var appointments = await _context.Appointments
                .Include(a => a.Trainer) // Eğitmen bilgisini veritabanından çek
                .OrderByDescending(a => a.AppointmentDate)
                .ToListAsync();
            return View(appointments);
        }

        // Randevuyu Onayla
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Approve(int id)
        {
            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment != null)
            {
                // Durumu güncelle
                appointment.Status = "Onaylandı";
                _context.Update(appointment);

                // --- BİLDİRİM OLUŞTURMA KISMI ---
                var notification = new Notification
                {
                    UserId = appointment.MemberId, // Bildirim kime gidecek?
                    Message = $"Tebrikler! {appointment.AppointmentDate:dd.MM.yyyy HH:mm} tarihli randevunuz onaylandı. ✅",
                    IsRead = false, // Okunmadı olarak işaretle (Kırmızı baloncuk çıksın)
                    CreatedDate = DateTime.Now
                };
                _context.Notifications.Add(notification);
                // --------------------------------

                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        // ---------------------------------------------------------
        // 2. REDDET METODU (BİLDİRİM EKLEYEN VERSİYON)
        // ---------------------------------------------------------
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Reject(int id)
        {
            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment != null)
            {
                // Durumu güncelle
                appointment.Status = "Reddedildi";
                _context.Update(appointment);

                // --- BİLDİRİM OLUŞTURMA KISMI ---
                var notification = new Notification
                {
                    UserId = appointment.MemberId,
                    Message = $"Üzgünüz, {appointment.AppointmentDate:dd.MM.yyyy HH:mm} tarihli randevunuz reddedildi. ❌",
                    IsRead = false,
                    CreatedDate = DateTime.Now
                };
                _context.Notifications.Add(notification);
                // --------------------------------

                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}