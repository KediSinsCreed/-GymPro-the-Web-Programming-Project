﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GymProMax.Data;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace GymProMax.Controllers
{
    [Authorize] // Sadece giriş yapanlar görebilsin
    public class NotificationController : Controller
    {
        private readonly ApplicationDbContext _context;

        public NotificationController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            // Bildirimleri tarihe göre (en yeni en üstte) getir
            var notifications = await _context.Notifications
                                        .Where(n => n.UserId == userId)
                                        .OrderByDescending(n => n.CreatedDate)
                                        .ToListAsync();

            // Sayfayı açtığı an hepsini "Okundu" yap (Kırmızı baloncuk sönmesi için)
            if (notifications.Any(n => !n.IsRead))
            {
                foreach (var notif in notifications.Where(n => !n.IsRead))
                {
                    notif.IsRead = true;
                }
                await _context.SaveChangesAsync();
            }

            return View(notifications);
        }
    }
}