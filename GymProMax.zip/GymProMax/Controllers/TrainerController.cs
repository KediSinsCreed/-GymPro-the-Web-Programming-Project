﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GymProMax.Data;
using GymProMax.Models;
using Microsoft.AspNetCore.Authorization;

namespace GymProMax.Controllers
{
    public class TrainerController : Controller
    {
        private readonly ApplicationDbContext _context;

        public TrainerController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index() => View(await _context.Trainers.ToListAsync());

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();
            var trainer = await _context.Trainers.FirstOrDefaultAsync(m => m.Id == id);
            return trainer == null ? NotFound() : View(trainer);
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Create() => View();

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Trainer trainer)
        {
            ModelState.Remove("Appointments");
            if (string.IsNullOrWhiteSpace(trainer.ImageUrl))
            {
                trainer.ImageUrl = "https://via.placeholder.com/300x300?text=No+Image";
                ModelState.Remove("ImageUrl");
            }

            if (ModelState.IsValid)
            {
                _context.Add(trainer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(trainer);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var trainer = await _context.Trainers.FindAsync(id);
            return trainer == null ? NotFound() : View(trainer);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Trainer trainer)
        {
            if (id != trainer.Id) return NotFound();
            ModelState.Remove("Appointments");

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(trainer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Trainers.Any(e => e.Id == trainer.Id)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(trainer);
        }

        // ---------------------------------------------------------
        // 1. SİLME ONAY SAYFASINI AÇAN METOT (GET)
        // Linke tıklayınca burası çalışır.
        // ---------------------------------------------------------
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var trainer = await _context.Trainers
                .FirstOrDefaultAsync(m => m.Id == id);

            if (trainer == null) return NotFound();

            return View(trainer);
        }

        // ---------------------------------------------------------
        // 2. KESİN SİLME İŞLEMİ (POST)
        // "Evet, Sil" butonuna basınca burası çalışır.
        // ---------------------------------------------------------
        [HttpPost, ActionName("Delete")]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            // Eğitmeni, randevularıyla (antrenmanlarıyla) birlikte çekiyoruz
            var trainer = await _context.Trainers
                .Include(t => t.Appointments)
                .FirstOrDefaultAsync(t => t.Id == id);

            if (trainer != null)
            {
                // İlişkili antrenman randevularını temizle (SQL Hatasını önler)
                if (trainer.Appointments != null && trainer.Appointments.Any())
                {
                    _context.Appointments.RemoveRange(trainer.Appointments);
                }

                _context.Trainers.Remove(trainer);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}