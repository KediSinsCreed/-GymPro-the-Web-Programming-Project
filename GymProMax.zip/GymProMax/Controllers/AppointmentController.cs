﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GymProMax.Data;
using GymProMax.Models;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace GymProMax.Controllers
{
    [Authorize]
    public class AppointmentController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AppointmentController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var appointments = await _context.Appointments
                .Include(a => a.Trainer)
                .Where(a => a.MemberId == userId)
                .OrderByDescending(a => a.AppointmentDate)
                .ToListAsync();
            return View(appointments);
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AdminIndex()
        {
            var allAppointments = await _context.Appointments
                .Include(a => a.Trainer)
                .OrderByDescending(a => a.AppointmentDate)
                .ToListAsync();
            return View(allAppointments);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> UpdateStatus(int id, string newStatus)
        {
            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment != null)
            {
                appointment.Status = newStatus;
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(AdminIndex));
        }

        // 4. RANDEVU ALMA SAYFASI (GET)
        public IActionResult Create()
        {
            ViewData["TrainerId"] = new SelectList(_context.Trainers, "Id", "FullName");

            ViewBag.Services = _context.Services.ToList();
            ViewData["ServiceName"] = new SelectList(_context.Services, "Name", "Name");
            return View();
        }

        // 5. RANDEVU KAYDETME (POST)

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Appointment appointment)
        {
            // 1. Giriş yapmış kullanıcının bilgilerini al
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var userEmail = User.Identity?.Name;

            appointment.MemberId = userId;
            appointment.MemberName = userEmail ?? "Bilinmeyen Üye";
            appointment.Status = "Bekliyor";

            // 2. ServiceName seçildiyse, ServiceId'yi veritabanından bulup eşle
            if (appointment.ServiceId == 0 && !string.IsNullOrEmpty(appointment.ServiceName))
            {
                var service = await _context.Services.FirstOrDefaultAsync(s => s.Name == appointment.ServiceName);
                if (service != null)
                {
                    appointment.ServiceId = service.Id;
                }
            }

            // 3. KRİTİK KISIM: Validasyon Hatalarını Temizle
            // Bu alanlar formdan gelmez, kodla doldurulur. O yüzden hata vermesini engelliyoruz.
            ModelState.Remove("Trainer");
            ModelState.Remove("Service");
            ModelState.Remove("Status");
            ModelState.Remove("MemberId");
            ModelState.Remove("MemberName");

            // 4. İŞ MANTIĞI KONTROLLERİ

            // A) Mesai Saati Kontrolü (09:00 - 20:00)
            var appointmentHour = appointment.AppointmentDate.Hour;
            if (appointmentHour < 9 || appointmentHour >= 20)
            {
                ModelState.AddModelError("", "Eğitmenlerimiz 09:00 - 20:00 arası hizmet vermektedir.");
            }

            // B) Geçmiş Tarih Kontrolü
            if (appointment.AppointmentDate < DateTime.Now)
            {
                ModelState.AddModelError("", "Geçmiş bir tarihe randevu alamazsınız.");
            }

            // C) Doluluk Kontrolü (Aynı eğitmen, aynı saatte dolu mu?) Çok detaylı değil sadece aynı andaki randevuları kontrol ediyoruz.
            bool isBusy = await _context.Appointments.AnyAsync(x =>
                x.TrainerId == appointment.TrainerId &&
                x.AppointmentDate == appointment.AppointmentDate &&
                x.Status != "Reddedildi");

            if (isBusy)
            {
                ModelState.AddModelError("", "Seçtiğiniz eğitmen bu tarih ve saatte dolu. Lütfen başka bir zaman seçin.");
            }

            // 5. Her şey tamamsa kaydet
            if (ModelState.IsValid)
            {
                _context.Add(appointment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index)); // Randevularım sayfasına git
            }

            // Hata varsa formu tekrar doldurup göster (ViewBag'leri unutma!)
            ViewBag.Services = _context.Services.ToList();
            ViewData["ServiceName"] = new SelectList(_context.Services, "Name", "Name", appointment.ServiceName);
            ViewData["TrainerId"] = new SelectList(_context.Trainers, "Id", "FullName", appointment.TrainerId);

            return View(appointment);
        }
    }
}