﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GymProMax.Data;
using GymProMax.Models;
using System.Text;
using System.Text.Json;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Authorization;

namespace GymProMax.Controllers
{
    public class GymServiceController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly HttpClient _httpClient;

        public GymServiceController(ApplicationDbContext context)
        {
            _context = context;
            _httpClient = new HttpClient();
        }

        // HERKES GÖREBİLİR
        public async Task<IActionResult> Index() => View(await _context.Services.ToListAsync());

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();
            var service = await _context.Services.FirstOrDefaultAsync(m => m.Id == id);
            return service == null ? NotFound() : View(service);
        }

        // SADECE ADMIN EKLEYEBİLİR
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Service service)
        {
            // Appointments listesi yeni oluşturulurken boş olacağı için hata vermesini engelliyoruz
            ModelState.Remove("Appointments");

            if (ModelState.IsValid)
            {
                _context.Add(service);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(service);
        }

        // SADECE ADMIN DÜZENLEYEBİLİR
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var service = await _context.Services.FindAsync(id);
            return service == null ? NotFound() : View(service);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Service service)
        {
            if (id != service.Id) return NotFound();
            if (ModelState.IsValid)
            {
                try { _context.Update(service); await _context.SaveChangesAsync(); return RedirectToAction(nameof(Index)); }
                catch (DbUpdateConcurrencyException) { if (!_context.Services.Any(e => e.Id == service.Id)) return NotFound(); else throw; }
            }
            return View(service);
        }

        // SADECE ADMIN SİLEBİLİR
        // ---------------------------------------------------------
        // 1. SİLME ONAY SAYFASINI GETİREN METOT (GET)
        // Linke tıkladığında burası çalışır ve onay ekranı açılır.
        // ---------------------------------------------------------
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var service = await _context.Services
                .FirstOrDefaultAsync(m => m.Id == id);

            if (service == null) return NotFound();

            return View(service);
        }

        // ---------------------------------------------------------
        // 2. GERÇEK SİLME İŞLEMİNİ YAPAN METOT (POST)
        // "Evet, Sil" butonuna bastığında burası çalışır.
        // ---------------------------------------------------------
        [HttpPost, ActionName("Delete")]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            // Hizmeti randevularıyla beraber çekiyoruz (Hata almamak için)
            var service = await _context.Services
                .Include(s => s.Appointments)
                .FirstOrDefaultAsync(s => s.Id == id);

            if (service != null)
            {
                // Önce bu hizmete ait randevuları temizle
                if (service.Appointments != null && service.Appointments.Any())
                {
                    _context.Appointments.RemoveRange(service.Appointments);
                }

                // Sonra hizmeti sil
                _context.Services.Remove(service);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        // HERKES ERİŞEBİLİR
        [HttpGet]
        public IActionResult AiTrainer() => View();

        [HttpPost]
        public async Task<IActionResult> AiTrainer(double weight, double height, string goal, string gender)
        {
            string apiKey = "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";
            if (apiKey.Contains("BURAYA_")) { ViewBag.Error = "API Key eksik!"; return View(); }

            string prompt = $"Ben {weight} kg, {height} cm, {gender} biriyim. Hedefim: {goal}. Bana bir fitness koçu gibi 3 günlük antrenman ve beslenme programı hazırla. Türkçe ve HTML formatında (<b>, <br>, <ul>) yaz.";
            string apiUrl = "https://api.groq.com/openai/v1/chat/completions";
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);

            var requestBody = new { model = "llama-3.3-70b-versatile", messages = new[] { new { role = "user", content = prompt } } };
            var jsonContent = new StringContent(JsonSerializer.Serialize(requestBody), Encoding.UTF8, "application/json");

            try
            {
                var response = await _httpClient.PostAsync(apiUrl, jsonContent);
                if (response.IsSuccessStatusCode)
                {
                    var responseString = await response.Content.ReadAsStringAsync();
                    using (JsonDocument doc = JsonDocument.Parse(responseString))
                    {
                        ViewBag.AiMessage = doc.RootElement.GetProperty("choices")[0].GetProperty("message").GetProperty("content").GetString();
                        ViewBag.ShowResult = true;
                    }
                }
            }
            catch (Exception ex) { ViewBag.Error = "Hata: " + ex.Message; return View(); }

            string genderTerm = gender == "Erkek" ? "man" : "woman";
            string imagePrompt = $"fitness photography of a {genderTerm} workout for {goal} in gym, cinematic lighting, high quality";
            string encodedPrompt = System.Net.WebUtility.UrlEncode(imagePrompt);
            ViewBag.GeneratedImageUrl = $"https://image.pollinations.ai/prompt/{encodedPrompt}?seed={new Random().Next(1, 999)}&width=800&height=500&nologo=true";

            return View();
        }
    }
}