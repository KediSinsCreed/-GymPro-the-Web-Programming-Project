﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GymProMax.Data;

namespace GymProMax.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TrainersApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public TrainersApiController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Sorgu: /api/TrainersApi/Search?expertize=Plates
        [HttpGet("Search")]
        public async Task<IActionResult> Search(string expertize)
        {
            // LINQ Filtreleme
            var trainers = await _context.Trainers
                .Where(t => t.Specialization.Contains(expertize))
                .Select(t => new { t.FullName, t.Specialization })
                .ToListAsync();

            if (trainers == null || !trainers.Any())
            {
                return NotFound(new { mesaj = $"{expertize} uzmanlığına sahip hoca bulunamadı." });
            }

            return Ok(trainers);
        }
    }
}