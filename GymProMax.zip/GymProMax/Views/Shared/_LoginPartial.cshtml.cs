using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymProMax.Views.Shared
{
    public class _LoginPatialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
