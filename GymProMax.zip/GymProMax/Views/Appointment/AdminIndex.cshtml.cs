using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymProMax.Views.Appointment
{
    public class AdminIndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
