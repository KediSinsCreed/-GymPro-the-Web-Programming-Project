using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymProMax.Views.GymService
{
    public class AiTrainerModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
