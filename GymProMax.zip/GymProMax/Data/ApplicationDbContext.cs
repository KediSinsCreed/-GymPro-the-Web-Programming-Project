﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using GymProMax.Models; // Modellerin olduğu namespace

namespace GymProMax.Data
{
    // IdentityDbContext: Üyelik sistemini (Login/Register) otomatik getirir.
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // Tablolarımızı burada tanıtıyoruz
        public DbSet<Trainer> Trainers { get; set; }

        public DbSet<Notification> Notifications { get; set; }
        public DbSet<Service> Services { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
    }
}